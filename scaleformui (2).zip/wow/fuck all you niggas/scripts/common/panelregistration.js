"use strict";

                                                                                                    
                                                                 
                                                                                                    

(function()
{  
                                                                               

                 
    UiToolkitAPI.RegisterPanel2d( 'CSGOPerfTestsJsMultipleContexts', 'file://{resources}/layout/tests/perf/perf_jsmultiplecontexts.xml' );
    UiToolkitAPI.RegisterPanel2d( 'CSGOPerfTestsJsSingleContext', 'file://{resources}/layout/tests/perf/perf_jssinglecontext.xml' );
    UiToolkitAPI.RegisterPanel2d( 'CSGOPerfTestsTypeSafety', 'file://{resources}/layout/tests/perf/type_safety.xml');

                                    
    UiToolkitAPI.RegisterPanel2d( 'ControlLibTestPanel', 'file://{resources}/layout/tests/controllibtestpanel.xml' );
})();