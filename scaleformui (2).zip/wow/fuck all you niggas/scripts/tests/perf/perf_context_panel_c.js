"use strict";


function OnLoadedC()
{
                       
}

function ButtonActivatedC()
{
                                                                                              
}

                                                                                                    
                                           
                                                                                                    
(function ()
{
                      
})();


